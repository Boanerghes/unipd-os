package os;

/**{i}
 * caratteristiche specifiche di un ADC
 *
 * @author M.Moro DEI UNIPD
 * @version 1.00 2004-11-12
 * @version 2.00 2005-10-07 package os
 */

class ADCType implements DeviceType
{
// da impostare

} //{i} ADCLineType
