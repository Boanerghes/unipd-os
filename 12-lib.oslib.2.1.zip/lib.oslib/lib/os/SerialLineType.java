package os;

/**{i}
 * caratteristiche specifiche di una linea seriale
 *
 * @author M.Moro DEI UNIPD
 * @version 1.00 2004-11-11
 * @version 2.00 2005-10-07 package os
 */

public class SerialLineType implements DeviceType
{
// da impostare

} //{i} SerialLineType
