package os.ada;

/**{c}
 * Allocatore 123 in Ada
 * stringhe utili
 * @author M.Moro DEI UNIPD
 * @version 1.00 2010-12-22
*/

public interface ADAAll123Str
{
    static final String all123Str = "all123";
      // nome del server
    static final String prel1Str = "prell";
    static final String prel2Str = "prel2";
    static final String prel3Str = "prel3";
    static final String rilaStr = "rila";
      // nome dei selettori

} //{c} ADAAll123Str

