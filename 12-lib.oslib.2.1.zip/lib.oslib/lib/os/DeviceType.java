package os;

/**{i}
 * interfaccia per caratteristiche
 * specifiche di un dispositivo
 *
 * @author M.Moro DEI UNIPD
 * @version 1.00 2003-10-18
 * @version 2.00 2005-10-07 package os
 */

public interface DeviceType
{
} //{i} DeviceType
