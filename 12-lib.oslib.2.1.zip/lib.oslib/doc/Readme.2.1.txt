v1.1    Aggiunta Regione Critica
v1.2    Condition di Monitor resa public, aggiunta SyncMultiBuf2 con due semafori, altre variazioni minori
v1.3    Aggiunto p(qty,timeout) in CountSem, aggiunto cWait(timeout) in Monitor.Condition, 
        aggiunto il set di classi per la simulazione dello strato di I/O
v1.4    Modificato package Os in os e altri aggiornamenti
v1.5    Aggiunto enterWhen(condition, timeout) in os.Region e readLong in os.SysRS
v1.5.a  Alcune correzioni in Region e Util; aggiunto Monitor.Condition.queue()
v1.5.b  Alcune correzioni nei file della simulazione I/O,
        corretta posizione di alcuni file di supporto
        (es. ADCSamples.dat)
v1.5.c  In 4 file sorgenti (PGraph, Region, Semaphore e SendRcv) le strutture
        di dati generiche 'vecchio stile' sono state sostituite dalla forma
        che utilizza i generics, evitando in fase di compilazione il warning
        relativo del compilatore
v2.0    Aggiunta l'emulazione del rendez-vous di ADA
v2.0.c  Bug fix su ADAThread
v2.1    Aggiunta terminazione thread nella Simulazione I/O
        Definito meglio il demo per RMI in osExtra
